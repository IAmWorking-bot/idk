"""
test

Description:
"""

chips = 100

got = 1

test1 = 1
#activation system
"""
buy = input("buy")
if buy == "yes":
    if chips >= 10:
        test1 = got
    else:
        print("no bueno")
else:
    print("no buy")
    
# plus stamtents
if test1 == got:
    test1 += 0.25
else:
    print("no")
print(test1)

score = chips * test1

print(score)
"""
#scale
base = 100
round1 = 6
growth = 3
scale = int(base*(growth*(round1)))
print(scale)